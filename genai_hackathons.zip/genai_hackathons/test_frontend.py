import streamlit as st
import requests
import pyrebase

# IMPORTANT: Paste your Firebase web app config here.
firebase_config = {
  "apiKey": "AIzaSyD-yFZCZo4P9le0cKSSW4vxpZXCXbL-gKs",
  "authDomain": "genai-472705.firebaseapp.com",
  "projectId": "genai-472705",
  "storageBucket": "genai-472705.appspot.com",
  "messagingSenderId": "763202871269",
  "appId": "1:763202871269:web:24b017b2d6911bf703990c",
  "databaseURL": ""
}

# --- Backend URL ---
BACKEND_URL = "http://127.0.0.1:5001"

# --- Initialize Firebase ---
try:
    firebase = pyrebase.initialize_app(firebase_config)
    auth_client = firebase.auth()
except Exception as e:
    st.warning(f"Could not initialize Firebase. Have you pasted your config? Error: {e}")

st.title("Backend Test Harness 🧪")
st.markdown("Use this to test your backend API endpoints for the Aether app.")

# --- TABS FOR ORGANIZATION ---
tab1, tab2, tab3 = st.tabs(["Users & Posts", "Echo Chamber", "View Databases"])

with tab1:
    st.header("1a. Test Signup Endpoint")
    signup_email = st.text_input("Test Email")
    signup_password = st.text_input("Test Password", type="password")
    if st.button("Create User and Profile"):
        with st.spinner("Calling /signup endpoint..."):
            try:
                # Step 1: Create the user in Firebase Auth to get the UID
                user = auth_client.create_user_with_email_and_password(signup_email, signup_password)
                uid = user['localId']
                st.info(f"Step 1 SUCCEEDED: User created in Firebase Auth with UID: {uid}")

                # Step 2: Call your backend with the UID to create the Firestore profile
                signup_payload = {"email": signup_email, "uid": uid}
                response = requests.post(f"{BACKEND_URL}/signup", json=signup_payload)
                
                if response.status_code == 201:
                    st.success("Step 2 SUCCEEDED: Backend created user profile in Firestore.")
                    st.json(response.json())
                else:
                    st.error("Step 2 FAILED: Backend could not create the user profile.")
                    st.json(response.json())

            except Exception as e:
                st.error(f"Step 1 FAILED: Could not create user in Firebase Auth. The email probably already exists.")
                st.write(e)

    st.markdown("---")

    # --- NEW: Login Test Section ---
    st.header("1b. Test Login Endpoint")
    st.info("Use the details of a user you have already signed up.")
    login_email = st.text_input("Email for Login", key="login_email")
    login_password = st.text_input("Password for Login", type="password", key="login_password")

    if st.button("Login Existing User"):
        with st.spinner("Attempting to log in..."):
            try:
                user = auth_client.sign_in_with_email_and_password(login_email, login_password)
                st.success("SUCCESS! Login successful.")
                st.info("You can use this user's details to test other endpoints.")
                st.json(user)
            except Exception as e:
                st.error("ERROR! Login failed. Check your credentials.")
                st.write(e)
    
    st.markdown("---")
    
    st.header("2. Test Create Post Endpoint")
    post_uid = st.text_input("User UID (from signup or login success message)", key="post_uid")
    post_username = st.text_input("Anonymous Username (from signup success message)", key="post_username")
    post_content = st.text_area("Post Content")
    if st.button("Create Post"):
        with st.spinner("Calling /posts endpoint..."):
            payload = {"uid": post_uid, "username": post_username, "content": post_content}
            response = requests.post(f"{BACKEND_URL}/posts", json=payload)
            
            if response.status_code == 201:
                st.success("SUCCESS! Post created.")
            else:
                st.error("ERROR! Failed to create post.")
            st.json(response.json())

with tab2:
    st.header("3. Test Create Echo Endpoint")
    # ... (The rest of the code is unchanged) ...
    st.info("You'll need a short .wav or .mp3 audio file on your computer to test this.")
    
    echo_uid = st.text_input("User UID (from a signed-up user)", key="echo_uid")
    uploaded_audio = st.file_uploader("Upload your audio file", type=["wav", "mp3"])

    if st.button("Create Echo"):
        if echo_uid and uploaded_audio:
            with st.spinner("Calling /echoes endpoint..."):
                files = {'audio': (uploaded_audio.name, uploaded_audio.getvalue(), uploaded_audio.type)}
                payload = {'uid': echo_uid}
                try:
                    response = requests.post(f"{BACKEND_URL}/echoes", files=files, data=payload)

                    if response.status_code == 201:
                        st.success("SUCCESS! Echo created.")
                        st.json(response.json())
                        st.write("Anonymized audio returned from backend:")
                        st.audio(response.json().get('url'))
                    else:
                        st.error("ERROR! Failed to create echo.")
                        st.json(response.json())
                except requests.exceptions.ConnectionError as e:
                    st.error(f"Connection Error: Could not connect to the backend. Is it running? Error: {e}")

        else:
            st.warning("Please provide a UID and upload an audio file.")

with tab3:
    st.header("4. View All Data")
    if st.button("Fetch All Posts"):
        with st.spinner("Calling GET /posts..."):
            response = requests.get(f"{BACKEND_URL}/posts")
            st.success("Posts Response:")
            st.json(response.json())
            
    if st.button("Fetch All Echoes"):
        with st.spinner("Calling GET /echoes..."):
            response = requests.get(f"{BACKEND_URL}/echoes")
            st.success("Echoes Response:")
            st.json(response.json())