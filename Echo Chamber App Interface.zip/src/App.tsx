import React from 'react';
import { GalaxyView } from './components/GalaxyView';
import { BottomNavigation } from './components/BottomNavigation';

export default function App() {
  return (
    <div className="size-full relative overflow-hidden bg-black">
      {/* Main Galaxy Interface */}
      <GalaxyView />
      
      {/* Bottom Navigation */}
      <BottomNavigation />
      
      {/* App Title Header */}
      <div className="absolute top-0 left-0 right-0 z-40 p-4">
        <div className="flex items-center justify-center">
          <h1 
            className="text-2xl tracking-wide bg-clip-text text-transparent"
            style={{
              backgroundImage: 'linear-gradient(135deg, rgba(255, 255, 255, 1) 0%, rgba(255, 105, 180, 0.9) 50%, rgba(138, 43, 226, 0.8) 100%)',
              filter: 'drop-shadow(0 0 8px rgba(255, 105, 180, 0.5))',
            }}
          >
            Echo Chamber
          </h1>
        </div>
      </div>
      
      {/* Ambient glow effects */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `
            radial-gradient(ellipse at 50% 0%, rgba(138, 43, 226, 0.1) 0%, transparent 50%),
            radial-gradient(ellipse at 0% 100%, rgba(255, 105, 180, 0.1) 0%, transparent 50%),
            radial-gradient(ellipse at 100% 100%, rgba(72, 61, 139, 0.1) 0%, transparent 50%)
          `
        }}
      />
    </div>
  );
}