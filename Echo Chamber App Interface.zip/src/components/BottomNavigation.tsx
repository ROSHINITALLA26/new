import React from 'react';
import { motion } from 'motion/react';
import { Home, MessageCircle, Search, User, Mic } from 'lucide-react';

export function BottomNavigation() {
  const navItems = [
    { icon: Home, label: 'Home', isActive: false },
    { icon: Search, label: 'Explore', isActive: false },
    { icon: MessageCircle, label: 'Echo Chamber', isActive: true },
    { icon: Mic, label: 'Record', isActive: false },
    { icon: User, label: 'Profile', isActive: false },
  ];

  return (
    <motion.div
      className="absolute bottom-0 left-0 right-0 z-50"
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <div 
        className="mx-4 mb-4 rounded-2xl border border-white/10 backdrop-blur-md"
        style={{
          background: 'rgba(10, 0, 21, 0.8)',
          boxShadow: '0 8px 32px rgba(138, 43, 226, 0.3)',
        }}
      >
        <div className="flex items-center justify-around px-4 py-3">
          {navItems.map((item, index) => (
            <motion.button
              key={item.label}
              className="flex flex-col items-center justify-center p-2 rounded-xl relative"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              style={{
                background: item.isActive 
                  ? 'linear-gradient(135deg, rgba(255, 105, 180, 0.2), rgba(138, 43, 226, 0.2))'
                  : 'transparent',
              }}
            >
              {item.isActive && (
                <motion.div
                  className="absolute inset-0 rounded-xl border border-white/20"
                  animate={{
                    boxShadow: [
                      '0 0 0 0 rgba(255, 105, 180, 0.4)',
                      '0 0 0 4px rgba(255, 105, 180, 0.1)',
                      '0 0 0 0 rgba(255, 105, 180, 0.4)',
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
              )}
              
              <item.icon 
                size={24}
                className={`${
                  item.isActive 
                    ? 'text-white drop-shadow-lg' 
                    : 'text-white/60'
                }`}
                style={{
                  filter: item.isActive 
                    ? 'drop-shadow(0 0 8px rgba(255, 105, 180, 0.8))'
                    : 'none'
                }}
              />
              
              {item.isActive && (
                <motion.div
                  className="mt-1 w-1 h-1 rounded-full bg-white"
                  animate={{
                    boxShadow: [
                      '0 0 4px rgba(255, 255, 255, 0.8)',
                      '0 0 8px rgba(255, 105, 180, 0.8)',
                      '0 0 4px rgba(255, 255, 255, 0.8)',
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
              )}
            </motion.button>
          ))}
        </div>
      </div>
    </motion.div>
  );
}