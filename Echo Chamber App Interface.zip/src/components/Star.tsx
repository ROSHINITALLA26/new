import React from 'react';
import { motion } from 'motion/react';

interface StarProps {
  id: string;
  x: number;
  y: number;
  size: 'small' | 'medium' | 'large';
  hasHalo?: boolean;
  isActive?: boolean;
  onClick?: () => void;
}

export function Star({ x, y, size, hasHalo = false, isActive = false, onClick }: StarProps) {
  const sizeMap = {
    small: 8,
    medium: 12,
    large: 16
  };

  const starSize = sizeMap[size];
  const haloSize = starSize * 2.5;

  return (
    <motion.div
      className="absolute cursor-pointer"
      style={{
        left: x - starSize / 2,
        top: y - starSize / 2,
      }}
      whileHover={{ scale: 1.2 }}
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
    >
      {/* Pulsing Halo */}
      {hasHalo && (
        <motion.div
          className="absolute rounded-full opacity-30"
          style={{
            width: haloSize,
            height: haloSize,
            left: -haloSize / 2 + starSize / 2,
            top: -haloSize / 2 + starSize / 2,
            background: 'radial-gradient(circle, rgba(255, 105, 180, 0.6) 0%, rgba(138, 43, 226, 0.4) 50%, transparent 100%)',
          }}
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      )}
      
      {/* Main Star */}
      <motion.div
        className="rounded-full relative overflow-hidden"
        style={{
          width: starSize,
          height: starSize,
          background: isActive 
            ? 'radial-gradient(circle, rgba(255, 255, 255, 1) 0%, rgba(255, 105, 180, 0.8) 70%, rgba(138, 43, 226, 0.6) 100%)'
            : 'radial-gradient(circle, rgba(255, 255, 255, 0.9) 0%, rgba(135, 206, 250, 0.7) 70%, rgba(72, 61, 139, 0.5) 100%)',
          boxShadow: isActive
            ? '0 0 20px rgba(255, 105, 180, 0.8), 0 0 40px rgba(255, 105, 180, 0.4)'
            : '0 0 15px rgba(135, 206, 250, 0.6), 0 0 30px rgba(135, 206, 250, 0.3)',
        }}
        animate={{
          opacity: [0.8, 1, 0.8],
        }}
        transition={{
          duration: 3 + Math.random() * 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        {/* Glitter effect */}
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            background: 'conic-gradient(from 0deg, transparent, rgba(255, 255, 255, 0.3), transparent, rgba(255, 255, 255, 0.3), transparent)',
          }}
          animate={{
            rotate: 360,
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "linear"
          }}
        />
      </motion.div>
    </motion.div>
  );
}