import React, { useState, useRef, useCallback } from 'react';
import { motion, PanInfo } from 'motion/react';
import { Star } from './Star';
import { CosmicBackground } from './CosmicBackground';

interface VoiceNote {
  id: string;
  x: number;
  y: number;
  size: 'small' | 'medium' | 'large';
  hasHalo: boolean;
  isActive: boolean;
  username: string;
  duration: number;
}

export function GalaxyView() {
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Generate random voice notes as stars
  const [voiceNotes] = useState<VoiceNote[]>(() => 
    Array.from({ length: 50 }, (_, i) => ({
      id: `voice-${i}`,
      x: Math.random() * 1000,
      y: Math.random() * 1000,
      size: ['small', 'medium', 'large'][Math.floor(Math.random() * 3)] as 'small' | 'medium' | 'large',
      hasHalo: Math.random() > 0.7,
      isActive: Math.random() > 0.8,
      username: `user${i}`,
      duration: Math.random() * 60 + 10,
    }))
  );

  const handlePan = useCallback((event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    setPosition(prev => ({
      x: prev.x + info.delta.x,
      y: prev.y + info.delta.y,
    }));
  }, []);

  const handleWheel = useCallback((event: WheelEvent) => {
    event.preventDefault();
    const delta = event.deltaY > 0 ? 0.9 : 1.1;
    const newScale = Math.max(0.5, Math.min(3, scale * delta));
    setScale(newScale);
  }, [scale]);

  const handlePinch = useCallback((event: any) => {
    const newScale = Math.max(0.5, Math.min(3, event.scale));
    setScale(newScale);
  }, []);

  const handleStarClick = (id: string) => {
    console.log('Playing voice note:', id);
    // Here you would implement voice note playback
  };

  return (
    <div 
      ref={containerRef}
      className="absolute inset-0 overflow-hidden cursor-grab active:cursor-grabbing"
      onWheel={handleWheel}
      style={{ touchAction: 'none' }}
    >
      <CosmicBackground />
      
      <motion.div
        className="absolute inset-0 origin-center"
        drag
        dragMomentum={false}
        onPan={handlePan}
        animate={{
          scale,
          x: position.x,
          y: position.y,
        }}
        transition={{
          type: "spring",
          damping: 50,
          stiffness: 300,
        }}
        onPinch={handlePinch}
      >
        <div className="relative w-full h-full">
          {voiceNotes.map((note) => (
            <Star
              key={note.id}
              id={note.id}
              x={note.x}
              y={note.y}
              size={note.size}
              hasHalo={note.hasHalo}
              isActive={note.isActive}
              onClick={() => handleStarClick(note.id)}
            />
          ))}
        </div>
      </motion.div>
      
      {/* Zoom indicator */}
      <motion.div
        className="absolute top-4 right-4 px-3 py-2 rounded-full border border-white/20 backdrop-blur-md"
        style={{
          background: 'rgba(10, 0, 21, 0.6)',
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <span className="text-white/80 text-sm">
          {Math.round(scale * 100)}%
        </span>
      </motion.div>
      
      {/* Zoom controls */}
      <motion.div
        className="absolute top-16 right-4 flex flex-col gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
      >
        <motion.button
          className="w-10 h-10 rounded-full border border-white/20 backdrop-blur-md flex items-center justify-center"
          style={{
            background: 'rgba(10, 0, 21, 0.6)',
          }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setScale(prev => Math.min(3, prev * 1.2))}
        >
          <span className="text-white text-lg">+</span>
        </motion.button>
        
        <motion.button
          className="w-10 h-10 rounded-full border border-white/20 backdrop-blur-md flex items-center justify-center"
          style={{
            background: 'rgba(10, 0, 21, 0.6)',
          }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setScale(prev => Math.max(0.5, prev * 0.8))}
        >
          <span className="text-white text-lg">−</span>
        </motion.button>
      </motion.div>
      
      {/* Instructions overlay */}
      <motion.div
        className="absolute bottom-24 left-4 right-4 p-4 rounded-2xl border border-white/10 backdrop-blur-md"
        style={{
          background: 'rgba(10, 0, 21, 0.6)',
        }}
        initial={{ opacity: 1, y: 0 }}
        animate={{ opacity: 0, y: 20 }}
        transition={{ delay: 4, duration: 1 }}
      >
        <p className="text-white/80 text-center text-sm">
          Drag to explore • Pinch to zoom • Tap stars to play voice notes
        </p>
      </motion.div>
    </div>
  );
}