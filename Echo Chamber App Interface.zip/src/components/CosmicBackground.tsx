import React from 'react';
import { motion } from 'motion/react';

export function CosmicBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Base gradient background */}
      <div 
        className="absolute inset-0"
        style={{
          background: `
            radial-gradient(ellipse at 20% 50%, rgba(138, 43, 226, 0.3) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 20%, rgba(255, 105, 180, 0.2) 0%, transparent 50%),
            radial-gradient(ellipse at 40% 80%, rgba(72, 61, 139, 0.4) 0%, transparent 50%),
            linear-gradient(180deg, #0a0015 0%, #1a0033 50%, #2d1b69 100%)
          `
        }}
      />
      
      {/* Animated nebula clouds */}
      <motion.div
        className="absolute inset-0"
        animate={{
          background: [
            'radial-gradient(ellipse 800px 600px at 10% 40%, rgba(138, 43, 226, 0.15) 0%, transparent 50%)',
            'radial-gradient(ellipse 800px 600px at 30% 60%, rgba(138, 43, 226, 0.15) 0%, transparent 50%)',
            'radial-gradient(ellipse 800px 600px at 10% 40%, rgba(138, 43, 226, 0.15) 0%, transparent 50%)',
          ]
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      
      <motion.div
        className="absolute inset-0"
        animate={{
          background: [
            'radial-gradient(ellipse 600px 800px at 90% 20%, rgba(255, 105, 180, 0.1) 0%, transparent 50%)',
            'radial-gradient(ellipse 600px 800px at 70% 40%, rgba(255, 105, 180, 0.1) 0%, transparent 50%)',
            'radial-gradient(ellipse 600px 800px at 90% 20%, rgba(255, 105, 180, 0.1) 0%, transparent 50%)',
          ]
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 5
        }}
      />
      
      {/* Twinkling stars background */}
      {Array.from({ length: 100 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full bg-white"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            width: Math.random() * 2 + 1,
            height: Math.random() * 2 + 1,
          }}
          animate={{
            opacity: [0, 1, 0],
            scale: [0.5, 1, 0.5],
          }}
          transition={{
            duration: Math.random() * 3 + 2,
            repeat: Infinity,
            delay: Math.random() * 5,
            ease: "easeInOut"
          }}
        />
      ))}
      
      {/* Cosmic dust particles */}
      {Array.from({ length: 50 }).map((_, i) => (
        <motion.div
          key={`dust-${i}`}
          className="absolute rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            width: Math.random() * 1 + 0.5,
            height: Math.random() * 1 + 0.5,
            background: 'rgba(135, 206, 250, 0.4)',
          }}
          animate={{
            x: [0, Math.random() * 100 - 50],
            y: [0, Math.random() * 100 - 50],
            opacity: [0.2, 0.6, 0.2],
          }}
          transition={{
            duration: Math.random() * 20 + 10,
            repeat: Infinity,
            ease: "linear"
          }}
        />
      ))}
    </div>
  );
}